package com.ProductCategories;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCategoriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCategoriesApplication.class, args);
	}

}
