package com.bilt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiltApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiltApplication.class, args);
	}

}
