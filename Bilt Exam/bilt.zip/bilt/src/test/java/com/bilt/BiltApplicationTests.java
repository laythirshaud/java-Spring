package com.bilt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiltApplicationTests {

	@Test
	void contextLoads() {
	}

}
