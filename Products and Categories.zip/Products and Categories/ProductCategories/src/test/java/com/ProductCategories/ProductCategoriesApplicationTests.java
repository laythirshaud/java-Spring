package com.ProductCategories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCategoriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
