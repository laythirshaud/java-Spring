package com.dia.studentsclasses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsClassesApplicationTests {

	@Test
	void contextLoads() {
	}

}
