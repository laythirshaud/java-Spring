package com.dia.studentsclasses.repositories;

import org.springframework.data.repository.CrudRepository;

import com.dia.studentsclasses.model.Enroll;


public interface EnrollRepo extends CrudRepository<Enroll, Long>{
	
}
