package com.dia.studentsclasses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsClassesApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsClassesApplication.class, args);
	}

}
